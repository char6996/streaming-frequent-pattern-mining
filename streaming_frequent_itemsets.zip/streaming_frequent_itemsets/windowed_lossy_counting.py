# windowed_lossy_counting.py

from collections import deque, defaultdict

class WindowedFrequentItemsets:
    def __init__(self, window_size):
        self.window_size = window_size  # Number of most recent transactions to retain
        self.transaction_window = deque()  # Holds last N transactions
        self.item_counts = defaultdict(int)  # Item frequency counter

    def add_transaction(self, transaction):
        # Add new transaction
        self.transaction_window.append(transaction)
        for item in transaction:
            self.item_counts[item] += 1

        # Remove oldest if window is full
        if len(self.transaction_window) > self.window_size:
            old_tx = self.transaction_window.popleft()
            for item in old_tx:
                self.item_counts[item] -= 1
                if self.item_counts[item] <= 0:
                    del self.item_counts[item]

    def get_frequent_items(self, support_threshold):
        # Return items that appear at least support_threshold times
        return {item: count for item, count in self.item_counts.items() if count >= support_threshold}
