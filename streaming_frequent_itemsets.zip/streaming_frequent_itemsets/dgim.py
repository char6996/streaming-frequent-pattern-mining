# dgim.py

from collections import deque

class DGIM:
    def __init__(self, window_size):
        self.window_size = window_size
        self.buckets = deque()  # Each bucket stores (size, timestamp)
        self.current_time = 0

    def _expire_old_buckets(self):
        threshold = self.current_time - self.window_size
        while self.buckets and self.buckets[-1][1] <= threshold:
            self.buckets.pop()

    def add_bit(self, bit):
        self.current_time += 1
        if bit == 1:
            # Add a new bucket of size 1 at current timestamp
            self.buckets.appendleft((1, self.current_time))
            self._merge_buckets()
        self._expire_old_buckets()

    def _merge_buckets(self):
        i = 0
        while i < len(self.buckets) - 2:
            size1, _ = self.buckets[i]
            size2, _ = self.buckets[i+1]
            size3, _ = self.buckets[i+2]
            if size1 == size2 == size3:
                # Merge the two oldest same-size buckets
                new_size = size1 + size2
                new_timestamp = self.buckets[i+1][1]
                del self.buckets[i]
                del self.buckets[i]
                self.buckets.insert(i, (new_size, new_timestamp))
            else:
                i += 1

    def estimate_count(self):
        total = 0
        for i, (size, timestamp) in enumerate(self.buckets):
            if i == len(self.buckets) - 1:
                total += size // 2  # Estimate half for the last bucket
            else:
                total += size
        return total
