# lossy_counting.py

import math

class LossyCounting:
    def __init__(self, epsilon):
        self.epsilon = epsilon  # Error margin (e.g., 0.1 = 10%)
        self.bucket_width = math.ceil(1 / epsilon)
        self.current_bucket = 1
        self.data = {}  # Format: {item: [count, delta]}
        self.N = 0  # Total items processed

    def add_transaction(self, transaction):
        self.N += 1
        for item in transaction:
            if item in self.data:
                self.data[item][0] += 1
            else:
                self.data[item] = [1, self.current_bucket - 1]

        # Periodically trim low-frequency items
        if self.N % self.bucket_width == 0:
            self._trim()

        self.current_bucket += 1

    def _trim(self):
        to_delete = []
        for item in self.data:
            count, delta = self.data[item]
            if count + delta <= self.current_bucket:
                to_delete.append(item)
        for item in to_delete:
            del self.data[item]

    def get_frequent_items(self, support_threshold):
        result = {}
        for item in self.data:
            count, _ = self.data[item]
            if count >= support_threshold:
                result[item] = count
        return result
