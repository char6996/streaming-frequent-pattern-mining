# simulate_data.py

import random
import time

def generate_iot_stream(n=20):
    """
    Simulate IoT data transactions. Each transaction is a list of events.
    """
    items = ['temperature_high', 'motion_detected', 'door_open', 'light_on']
    for _ in range(n):
        transaction = random.sample(items, k=random.randint(1, 3))
        yield transaction
        time.sleep(0.2)  # Simulate delay (optional)

def generate_binary_stream(n=20):
    """
    Simulate a binary stream (e.g., click = 1, no click = 0).
    """
    for _ in range(n):
        bit = random.choice([0, 1])
        yield bit
        time.sleep(0.2)  # Simulate delay (optional)
