# main.py

from dgim import DGIM
from lossy_counting import LossyCounting
from windowed_lossy_counting import WindowedFrequentItemsets  # NEW
from simulate_data import generate_binary_stream, generate_iot_stream

def test_dgim():
    print("\n=== DGIM Algorithm Test (Static Stream) ===")
    stream = [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1]
    window_size = 5
    dgim = DGIM(window_size=window_size)

    for i, bit in enumerate(stream):
        dgim.add_bit(bit)
        estimate = dgim.estimate_count()
        print(f"After bit {i+1} ({bit}) → Estimated 1s in last {window_size}: {estimate}")

def test_lossy_counting():
    print("\n=== Lossy Counting for Frequent Itemsets (Static Stream) ===")
    transactions = [
        ['A', 'B'],
        ['B', 'C'],
        ['A', 'C'],
        ['A', 'B'],
        ['A'],
        ['C'],
        ['B', 'C'],
        ['C'],
        ['A', 'C'],
        ['B']
    ]

    lc = LossyCounting(epsilon=0.2)

    for i, tx in enumerate(transactions):
        lc.add_transaction(tx)
        print(f"Transaction {i+1}: {tx}")

    print("\nFrequent items with support ≥ 2:")
    frequent_items = lc.get_frequent_items(support_threshold=2)
    for item, count in frequent_items.items():
        print(f"{item}: {count}")

def test_live_dgim():
    print("\n=== DGIM Algorithm Test (Live Simulated Binary Stream) ===")
    dgim = DGIM(window_size=10)
    for bit in generate_binary_stream(n=15):
        print(f"Received bit: {bit}")
        dgim.add_bit(bit)
        print(f"Estimated 1s in last 10: {dgim.estimate_count()}")

def test_live_lossy_counting():
    print("\n=== Lossy Counting Test (Live Simulated IoT Stream) ===")
    lc = LossyCounting(epsilon=0.25)
    for tx in generate_iot_stream(n=10):
        print(f"Received transaction: {tx}")
        lc.add_transaction(tx)

    print("\nFrequent items (support ≥ 2):")
    frequent_items = lc.get_frequent_items(support_threshold=2)
    for item, count in frequent_items.items():
        print(f"{item}: {count}")

def test_windowed_frequent_itemsets():
    print("\n=== Frequent Itemsets with Sliding Window (Decaying Window Model) ===")
    window = WindowedFrequentItemsets(window_size=5)

    transactions = [
        ['A', 'B'],
        ['B', 'C'],
        ['A', 'C'],
        ['A', 'B'],
        ['C'],
        ['A', 'C'],
        ['B'],
        ['C', 'B'],
        ['A'],
        ['A', 'B']
    ]

    for i, tx in enumerate(transactions):
        window.add_transaction(tx)
        frequent = window.get_frequent_items(support_threshold=2)
        print(f"After transaction {i+1}: {tx} → Frequent items: {frequent}")

if __name__ == "__main__":
    test_dgim()
    test_lossy_counting()
    test_live_dgim()
    test_live_lossy_counting()
    test_windowed_frequent_itemsets()  # NEW
